import { CategoryService } from './../../app/services/category.service';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ProductService } from '../../app/services/product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule, NgClass, NgIf } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-product-form',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule],
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.css'
})
export class ProductFormComponent {
  productForm: FormGroup;
  // product = Product;
  categories: any[] = []; // Replace any with your category model
  productId: number | null = null;


  constructor(
    private fb: FormBuilder,
     private productService: ProductService,
     private categoryService: CategoryService,
   // private categoryService: CategoryService,
    private route: ActivatedRoute,
    private router: Router
  ) {

    this.productForm = this.fb.group({
      productName: [, Validators.required],
      categoryId: ['', Validators.required],
      description: ['', Validators.required],
      productNumber: ['', Validators.required],
      standardCost: ['', [Validators.required, Validators.min(0)]],
      listCost: ['', [Validators.required, Validators.min(0)]],
      productPhotoUrl: ['', Validators.required]
    });

  //   this.productForm = this.fb.group({
  //     productName: [''],
  //     categoryId: [''],
  //     description: [''],
  //     standardCost: [''],
  //     listCost: [''],
  //     productPhotoUrl: ['']
  // });

  }

  ngOnInit(): void {
    this.loadCategories();
    // this.route.params.subscribe(params => {
    //   if (params['id']) {
    //     this.productId = +params['id'];
    //     this.loadProduct();
    //   }
    // });
  }

  loadCategories(): void {
    this.categoryService.getCategories().subscribe(categories => {
      this.categories = categories;
    });
  }

  handleGetProductSubCategory(event : any): void{
    console.log("handleGetProductSubCategory calling" , event.target.value);
    this.categoryService.getSubCategories(event.target.value).subscribe(result => {
      console.log("result", result);

    });
  }
  // loadProduct(): void {
  //   if (this.productId) {
  //     this.productService.getProductById(this.productId).subscribe(product => {
  //       this.productForm.patchValue({
  //         productName: product.productName,
  //         categoryId: product.categoryId,
  //         description: product.description,
  //         standardCost: product.standardCost,
  //         listCost: product.listCost,
  //         productPhotoUrl: product.productPhotoUrl
  //       });
  //     });
  //   }
  // }

  save() {
    console.log("hello world");
    if (this.productForm.valid) {
        const product = this.productForm.value;
        this.productService.createProduct(product).subscribe(() => {
            this.router.navigate(['/products']);
        });
     }
}
}
