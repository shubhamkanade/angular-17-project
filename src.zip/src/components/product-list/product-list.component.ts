import { Component } from '@angular/core';
import { ProductService } from '../../app/services/product.service';
import { FormsModule, NgModel } from '@angular/forms';
import { CommonModule, NgForOf } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [FormsModule, CommonModule,],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {
  products: any[] = [];
  categories: any[] = [];
  searchCriteria: any = {
      productName: '',
      categoryId: '',
      minCost: '',
      maxCost: ''
  };
  currentPage: number = 1;
  totalPages: number = 1;
  pages: number[] = [];

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
      this.loadCategories();
      this.loadProducts();
  }

  loadCategories(): void {
      // this.productService.getCategories().subscribe(categories => {
      //     this.categories = categories;
      // });
  }

  loadProducts(): void {
      this.productService.getProducts().subscribe(data => {
          this.products = data;
          // this.totalPages = data.totalPages;
          // this.pages = Array.from({ length: this.totalPages }, (_, i) => i + 1);
      });
  }

  searchProducts(): void {
      this.currentPage = 1;
      this.loadProducts();
  }

  sortProducts(column: string): void {
      // Implement sorting logic based on the column
  }

  changePage(page: number): void {
      this.currentPage = page;
      this.loadProducts();
  }

  editProduct(productId: number): void {
      // Implement navigation to edit page
  }

  viewProduct(productId: number): void {
      // Implement navigation to details page
  }
}
