export interface Product {
  id: number;
  productName: string;
  categoryId: number;
  descriptionId: number;
  standardCostId: number;
  listCostId: number;
  productPhotoId: number;
}
