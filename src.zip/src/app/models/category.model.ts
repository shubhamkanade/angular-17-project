export interface Category {
  id: number;
  productName: string;
  categoryId: number;
  descriptionId: number;
  standardCostId: number;
  listCostId: number;
  productPhotoId: number;
}
