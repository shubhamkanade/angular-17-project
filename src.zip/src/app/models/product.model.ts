export interface Product {
  id: number;
  productNumber: String;
  productName: String;
  categoryId: number | null;
  description: String;
  standardCostId: number;
  listCostId: number;
  productPhotoId: String;
}
